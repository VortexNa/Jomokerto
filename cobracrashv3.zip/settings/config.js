/*
  >> Control <<
*/
global.owner = ['62895324142219`']
global.ownername = "SanzXD Official"
global.connect = true // ubah ke false klo mau connect lewat qrcode 
global.antilink = false
global.autotyping = false
global.prefix = '.'

/*
  >> Message <<
*/
global.mess = {
"ketua": " ⇝ Access Denied \nKhusus Owner",
"prem": "⇝ Access Denied \nBeli Akses Premium Di Owner",
"premium": "⇝ Access Denied \nBeli Akses Premium Di Owner",
"japost": " -- Format Japost Tidak Tersedia -- ",
"rekber": " -- List Rekber Tidak Tersedia -- ",
"owner": " ⇝ Access Denied \nKhusus Owner"
}

/*
  >> MISC <<
*/
global.tele = "t.me/SanzXDOfficial"
global.tele2 = "t.me/"
global.waMe = "wa.me/"
global.tutorialBot = "https://youtube.com/@SanzXDOfficial" 
global.thumbimg = ""// Untuk menggampangkan buyer awam saat beli panel 
global.versionofscript = "8.0"
global.url = "" // buat banner
global.urlbanner = "" // buat banner 2
global.url2 = "" // isi url bebas buat reply
global.packname = "-̃" // sticker
global.author = "" // sticker
global.group = "" // isi group bebas lu
global.idCH = "" //idch
global.xchannel = {
	jid: '' //idch
	}
	